---
name: "Candibet Clubhouse"
description: "A warm, readable sports companion."
colors:
  "paper": "#f0ede9"
  "night": "#e9e5df"
  "card": "#fff"
  "card2": "#faf8f5"
  "chip": "#e9e4dd"
  "field": "#f7f5f1"
  "ink": "#282625"
  "mut": "#69615a"
  "line": "#ded8d0"
  "control-line": "#b8afa5"
  "acc": "#ae452c"
  "acc-soft": "#f8e9e1"
  "on-acc": "#fff"
  "data-accent": "#69615a"
  "gold": "#91601e"
  "bad": "#af3038"
  "bad-soft": "#fbecef"
  "positive": "#276448"
  "dark-paper": "#181716"
  "dark-night": "#121211"
  "dark-card": "#242220"
  "dark-card2": "#2b2825"
  "dark-chip": "#35312d"
  "dark-field": "#1e1c1a"
  "dark-ink": "#f1ede7"
  "dark-mut": "#bcb3a9"
  "dark-line": "#403b35"
  "dark-control-line": "#81766b"
  "dark-acc": "#efae94"
  "dark-acc-soft": "#493027"
  "dark-on-acc": "#302018"
  "dark-data-accent": "#bcb3a9"
  "dark-gold": "#dfbd7e"
  "dark-bad": "#f7a4ae"
  "dark-bad-soft": "#462b30"
  "dark-positive": "#9ec9ad"
typography:
  headline:
    fontFamily: "Nunito Sans, sans-serif"
    fontSize: "28px"
    fontWeight: 700
    lineHeight: 1.2
    letterSpacing: "-0.025em"
  title:
    fontFamily: "Nunito Sans, sans-serif"
    fontSize: "20px"
    fontWeight: 700
    lineHeight: 1.3
    letterSpacing: "-0.025em"
  body:
    fontFamily: "Nunito Sans, sans-serif"
    fontSize: "14px"
    fontWeight: 400
    lineHeight: 1.5
  label:
    fontFamily: "Nunito Sans, sans-serif"
    fontSize: "13px"
    fontWeight: 700
  price:
    fontFamily: "Nunito Sans, sans-serif"
    fontSize: "16px"
    fontWeight: 550
rounded:
  "control": "10px"
  "search": "12px"
  "fixture": "16px"
  "tray": "18px"
  "card": "20px"
  "sheet": "24px"
  "pill": "24px"
spacing:
  "8": "8px"
  "12": "12px"
  "16": "16px"
  "18": "18px"
  "20": "20px"
  "22": "22px"
  "24": "24px"
  "28": "28px"
  "32": "32px"
  "36": "36px"
components:
  button-primary:
    backgroundColor: "{colors.acc}"
    textColor: "{colors.on-acc}"
    rounded: "{rounded.control}"
    padding: "10px 16px"
    height: "40px"
  button-ghost:
    backgroundColor: "transparent"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "10px 16px"
  search:
    backgroundColor: "{colors.card}"
    textColor: "{colors.mut}"
    rounded: "{rounded.search}"
    padding: "0 16px"
    height: "50px"
  sport-chip:
    backgroundColor: "transparent"
    textColor: "{colors.mut}"
    rounded: "{rounded.pill}"
    padding: "10px 17px"
    height: "44px"
  sport-chip-selected:
    backgroundColor: "{colors.ink}"
    textColor: "{colors.paper}"
    rounded: "{rounded.pill}"
  fixture-card:
    backgroundColor: "{colors.card}"
    textColor: "{colors.ink}"
    rounded: "{rounded.fixture}"
    padding: "18px 22px 20px"
  price-choice:
    backgroundColor: "{colors.field}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "10px 14px"
    height: "46px"
---

# Design System: Candibet Clubhouse

## Overview

**Creative North Star: "Clubhouse"**

Clubhouse is a comfortable sports companion: warm stone surrounds white surfaces, brown-black ink and restrained burnt-orange actions. Humanist typography and roomy controls keep fixtures, supplied prices and evidence readable. The dark theme translates the same materials into warm charcoal.

Candibet keeps its Portuguese identity. Public research remains accessible before account entry; data provenance and missing or failed states stay explicit. Light is the initial theme; a saved light or dark preference takes precedence.

**Key Characteristics:**
- Warm neutral materials with a restrained action color.
- Humanist type and tabular prices.
- Rounded fixture objects with quiet supporting rails.

## Colors

The palette combines warm stone and brown-black neutrals with a burnt-orange action accent. Frontmatter records the shipped light palette and its `dark-` counterparts; CSS semantic variables switch at the theme root.

### Primary

- **Burnt Orange / Warm Peach:** `acc` marks primary actions, links and focus; `acc-soft` supports selection; `on-acc` supplies contrast on filled actions.

### Secondary

- **Quiet Gold:** `gold` identifies saved fixtures.
- **Positive Green / Error Rose:** `positive`, `bad` and `bad-soft` communicate actual status and errors.

### Neutral

- **Stone Ground:** `paper` and `night` establish the canvas.
- **White and Warm Chalk:** `card`, `card2`, `field` and `chip` distinguish surfaces and controls.
- **Brown-Black Ink:** `ink` is primary text; `mut` and `data-accent` support secondary information.
- **Warm Rules:** `line` divides content; `control-line` gives interactive boundaries stronger definition.

**The Neutral Data Rule.** Use neutral surfaces for prices; reserve accent treatment for actions and selection.

## Typography

**Display Font:** Nunito Sans, sans-serif.
**Body Font:** Nunito Sans, sans-serif.

Local regular and bold faces are served from `/fonts/`; their license is `web/public/fonts/OFL-NunitoSans.txt`. The CSS maps regular to weights 400–600 and bold to 650–900. Headings use a humanist, sentence-case voice with slight negative tracking.

### Hierarchy

- **Headline:** page headings; mobile sports and match headings reduce to 24px.
- **Title:** section headings; supporting rail headings commonly use 18px.
- **Body:** ordinary interface text; descriptive supporting copy can use a 1.6 or 1.7 line height.
- **Label:** filters and actions; metadata is commonly 11–12px.
- **Price:** primary odds; mobile prices reduce to 15px. Featured odds use bold weight.

**The Shared Voice Rule.** Use Nunito Sans for headings, prose and numbers; enable tabular numerals for prices, scores and balances.

## Layout

The desktop frame has a maximum width of 1392px with 36px side padding. Sports discovery uses a fluid main column, a 260px rail and a 32px gap. At 1100px, gutters become 24px, the rail 220px and the gap 24px. At 900px the rail moves below the main column; account panels become one column. At 760px gutters become 16px, top navigation gives way to fixed bottom navigation, and featured cards form a snapping horizontal strip within the page. Supporting rail sections stack vertically.

An open desktop betslip reserves 392px on the right above 1200px and relocates rail content below the main column. Mobile content reserves 76px plus the safe-area inset; the tray sits above that navigation. Casino supplied-price groups become a vertical list on phones. Use the observed spacing steps in frontmatter, with generous inter-section separation and tighter metadata grouping.

## Elevation & Depth

Content cards are flat, separated by tonal layering and thin rules. Floating auth sheets and betslip trays use restrained warm shadows; the inline guest invitation has no shadow. Modal backdrops dim the canvas without blur.

### Shadow Vocabulary

- **Auth sheet:** `0 16px 64px #17120d26`.
- **Desktop betslip:** `0 8px 32px #17120d12`.
- **Mobile betslip:** `0 -4px 24px #17120d14`.

**The Quiet Surface Rule.** Use borders and tonal layers for content; reserve ambient shadows for floating trays and dialogs.

## Shapes

Controls use gently curved corners; fixture rows and supporting panels are rounder, and major cards and sheets have the broadest corners. Sport filters are pills. Team initials use a small shield-like silhouette rather than imported badges. Supporting rail rows and casino activity sections use rules rather than independent rounded boxes.

## Components

### Buttons

Primary actions are filled with the action accent and contrasting text. Ghost actions use transparent backgrounds and a boundary; hover fills with the neutral chip tone. Ordinary controls have a 40px minimum height, with key mobile and transactional actions at 44–48px. Press feedback moves enabled buttons down 1px. Disabled buttons reduce opacity and disallow action.

### Chips

Sport chips pair authored SVG icons, labels and counts. Unselected chips are transparent with a control boundary; selected chips use ink on paper in reverse. They scroll horizontally within the viewport.

### Cards / Containers

Fixtures keep team names, time, provenance and prices together. Standard fixture cards use the fixture radius; featured cards use the larger card radius with 20px 24px 24px padding on desktop. Small screens reduce padding and type without hiding evidence. Secondary casino activity sections use top rules and content-led heights.

### Inputs / Fields

Fields use the field tone, control border and control radius, with a 44px minimum height. Search is a wider card-colored container with an inline SVG and clear action. Focus uses the accent outline; the search container outlines on focus within. Auth text fields use 16px on phones. Errors use the semantic error color.

### Navigation

Desktop navigation is quiet text with an ink underline for the active destination. Mobile navigation uses icon-and-label buttons, neutral defaults, and an accent-soft active background. Contextual search follows the destination; utility actions sit alongside it on larger screens.

### Price choices and betslip

Prices use tabular figures and neutral field surfaces; the lighter theme selects with accent-soft fill and an accent border. Existing more-specific dark selectors fill selected standard odds with the accent and use contrasting price text. The betslip uses the same rounded field and action vocabulary, remaining a floating desktop tray or a bottom sheet above mobile navigation. Preserve pending, disabled, validation and transaction states.

Motion uses short color and boundary transitions (160ms with `cubic-bezier(.16,1,.3,1)`) and restrained press feedback. Reduced-motion preference removes animation and transitions through the cascade.

## Do's and Don'ts

### Do:

- Do retain both warm light and warm charcoal themes.
- Do keep prices, source labels and refresh or error states legible.
- Do use authored SVG icons and visible keyboard focus.
- Do preserve safe-area space below mobile content and above fixed navigation.

### Don't:

- Don't introduce neon green or a condensed display face as the new visual identity.
- Don't fabricate market popularity, statistics or promotional claims.
- Don't turn every supporting section into nested cards.


Not canonized: 21 preexisting game rasters lack provenance metadata in the inherited inventory. This pass neither created nor replaced those assets; their metadata gaps remain documented in `.impeccable/review/raster-provenance-scan.txt`, not promoted into an asset policy.
