import "./globals.css";
import "./workspace.css";
import "./apex.css";
import "./clubhouse.css";

export const metadata = {
  title: "Candibet — Cotações Esportivas",
  description: "Cotações esportivas ao vivo, mercados e análise de partidas. Candibet, 18+.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR" data-theme="light">
      <head>
        <link rel="preload" href="/fonts/NunitoSans-Regular.ttf" as="font" type="font/ttf" crossOrigin="anonymous" />
        <link rel="preload" href="/fonts/NunitoSans-Bold.ttf" as="font" type="font/ttf" crossOrigin="anonymous" />
        {/* Set before first paint so the reveal layer can hide only when
            JavaScript is actually available; no-JS readers still get the
            whole page. */}
        <script
          dangerouslySetInnerHTML={{
            __html: "document.documentElement.classList.add('js');try{const t=localStorage.getItem('casa-theme');if(t==='dark'||t==='light')document.documentElement.dataset.theme=t}catch{}",
          }}
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
