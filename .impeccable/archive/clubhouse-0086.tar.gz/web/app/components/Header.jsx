"use client";

import { BRL } from "../../lib/api";
import UIIcon from "./UIIcon";

export default function Header({ view, casinoCat, unlocked, liveOnly, query, profile, player, admin, theme, favoritesOnly, onFavorites, onCasino, onSport, onQuery, onPromos, onAdmin, onTheme, onCash, onAccount, onHelp, onPortal }) {
  return <>
    <header className="sticky clubhouse-header">
      <div className="hwrap">
        <button className="logo" aria-label="Candibet início" onClick={() => onSport(false)}>
          <svg className="club-mark" width="28" height="28" viewBox="0 0 28 28" fill="none" aria-hidden="true"><path d="M21 6a10 10 0 1 0 0 16M21 11a4 4 0 1 0 0 6" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" /></svg>
          <span>candibet</span>
        </button>
        <nav className="main" aria-label="Navegação principal">
          <button className={view === "sport" && !liveOnly && !favoritesOnly ? "on" : ""} aria-current={view === "sport" && !liveOnly && !favoritesOnly ? "page" : undefined} onClick={() => onSport(false)}>Esportes</button>
          <button className={view === "sport" && liveOnly ? "on" : ""} onClick={() => onSport(true)}><UIIcon name="live" size={16} />Ao vivo</button>
          <button className={view === "sport" && favoritesOnly ? "on" : ""} onClick={onFavorites}>Favoritos</button>
          {unlocked ? <button className={view === "casino" ? "on" : ""} onClick={() => onCasino(casinoCat || "Todos")}>Cassino</button> : null}
        </nav>
        <div className="club-header-actions">
          {profile ? <span className="bal"><span>Saldo disponível</span>{BRL(profile.available_minor)}{profile.bonus_minor > 0 ? <small> + {BRL(profile.bonus_minor)} bônus</small> : null}</span> : null}
          {player ? <button className="ghost header-cash" onClick={onCash}><UIIcon name="wallet" size={18} />Depositar</button> : null}
          <button className="ghost header-theme" aria-label={theme === "light" ? "Ativar tema escuro" : "Ativar tema claro"} title={theme === "light" ? "Tema escuro" : "Tema claro"} onClick={onTheme}><UIIcon name={theme === "light" ? "moon" : "sun"} /></button>
          <button className={"club-account-button" + (player ? " is-member" : "")} onClick={onAccount}><UIIcon name="user" size={18} /><span>{player ? "Minha conta" : "Entrar"}</span></button>
        </div>
      </div>
    </header>
    <div className="club-search-row">
      <label className="club-search"><UIIcon name="search" /><input id="search" aria-label={view === "casino" ? "Buscar jogos ou provedores" : "Buscar times, ligas ou países"} placeholder={view === "casino" ? "Buscar jogo ou provedor" : "Buscar time, competição ou país"} value={query} onChange={e => onQuery(e.target.value)} />{query ? <button className="club-search-clear" aria-label="Limpar busca" onClick={() => onQuery("")}><UIIcon name="close" size={16} /></button> : null}</label>
      <nav className="club-utilities" aria-label="Serviços">
        {player ? <button onClick={onPromos}>Promoções</button> : null}
        {admin ? <button onClick={onAdmin}>Painel</button> : null}
        <button className={view === "dados" ? "on" : ""} onClick={onPortal}><UIIcon name="data" size={16} />Dados</button>
        <button onClick={onHelp}><UIIcon name="help" size={16} />Ajuda</button>
      </nav>
    </div>
  </>;
}
